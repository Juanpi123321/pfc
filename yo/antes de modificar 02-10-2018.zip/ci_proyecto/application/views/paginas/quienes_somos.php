<!-- principal quienes somos-->
	<div class="container-fluid fondo-principal">
		<div class="container fondo-2">
			<div class="row">
				<br>
				<div class="titulo text-center">
					<h2>QUIENES SOMOS</h2>
				</div>
				<br>
			</div>
			<div class="row">
				<div class="col-sm-4 col-md-4" style="margin-bottom: 30px;">
					<img src="<?php echo base_url(); ?>assets/img/pcgamer-logo-grande.png" alt="" class="img-responsive">
				</div>
				<div class="col-sm-8 col-md-7 col-md-offeset-1">
					<div class="margen-izq text-justify text-grande" style="margin-right: 15px;">
						<p>Hace más de 12 años, cuando la Tecnología se expandía a millones de personas en el mundo, se encendía en nosotros la vocación de brindar productos tecnológicos de calidad y atención personalizada.<br />
						Así nacía: <strong>Pc-GamerZ.</strong></p>
						<p>Todos estos años hemos escuchado a nuestros clientes, sus inquietudes y necesidades, nos hemos capacitado y perfeccionado para ofrecer una experiencia de compra diferente.<br />
						La tecnología evoluciona constantemente, nosotros también. En esa evolución, crecemos, nos adaptamos, nos encendemos.</p>
						<p><strong>Hoy llega &#8220;Pc-GamerZ&#8221;: una empresa Argentina, joven, líder en comercialización de productos y servicios de tecnología.</strong> Somos distribuidores oficiales de productos de primeras marcas, con garantía oficial y precios inmejorables, enviamos a todo el país y a miles de clientes particulares, pymes, instituciones educativas y gubernamentales.</p>
						<p>Creemos en lo que hacemos y agradecemos la confianza, queremos ser parte de tu vida, queremos encender tu pasión por la tecnología.</p>
					</div><br>
				</div>
            </div>
	            <br><br><br><br><br><br><br>        
		</div>
	</div>