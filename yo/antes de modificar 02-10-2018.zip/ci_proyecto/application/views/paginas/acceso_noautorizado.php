
<!-- principal -->
			<div class="container-fluid fondo-principal">
				<div class="container fondo-1">
					<div class="row">
						<br>
						<div class="titulo text-center">
							<h2>ACCESO NO AUTORIZADO</h2>
						</div>						
						<br>
						<img class="center-block" style="width: 60%;" src="<?php echo base_url(); ?>/assets/img/acceso_noautorizado.png">
						<br><br>
						<div class="text-center">
							<h1><b>ATENCION</b></h1>
							<h2>Esta intentando acceder a una zona restringida</h2>
						</div>
							
						</div>						
						<br>
						<br>
						<br>
						<br>
						<br>
				    </div>
				</div>
			</div>

			
			 