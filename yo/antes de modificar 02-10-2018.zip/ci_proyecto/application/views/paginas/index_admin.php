<!-- principal -->
	<div class="container-fluid fondo-principal">
		<div class="container fondo-1">
			<!-- principal -->
			<div class="row">
				<br>
				<div class="titulo text-center">
					<h2>ACCESO PERSONAL ADMINISTRATIVO</h2>
				</div>
				<br>
				<img style="width: 100%;" src="<?php echo base_url(); ?>/assets/img/restringido.jpg">
				<br><br>
				<h2 class="text-center">ATENCION</h2>
				<h3 class="text-center" style="margin: 30px;">Esta accediendo a un menu restringido solo para administrador de la empresa</h3>
				<br><br>
				<h3 class="text-center"></h3>
				<a style="padding-top: 0;" href="<?php echo base_url(); ?>pcgamer"><button class="btn btn-primary center-block">Ir a la parte de Cliente</button></a>
				<br><br>
			</div>

			<br><br>
		</div>
	</div>	