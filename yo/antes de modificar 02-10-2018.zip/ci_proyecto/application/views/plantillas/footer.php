
	<!-- pie -->
	<footer class="pie text-center">
		<div class="hidden-xs">
			<p>&#169 2018 Juanpi Gallardo Front-End Developer. All rights reserved.</p>
		</div>
		<div class="visible-xs">
			<p class="small">&#169 2017 Juanpi Gallardo Front-End Developer.</p>
		</div>
	</footer>
	<script src="<?php echo base_url(); ?>assets/BS/js/jquery-3.2.0.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/BS/js/bootstrap.js"></script>
	<!-- es un script para que funcione el tooltip y el popover-->
	<script src="<?php echo base_url(); ?>assets/BS/js/main.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-116573257-1"></script>
    <script>
         window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());

         gtag('config', 'UA-116573257-1');
    </script>

</body>
</html>
